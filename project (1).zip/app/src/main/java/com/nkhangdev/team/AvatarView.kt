package com.nkhangdev.team
import android.content.Context
import android.graphics.*
import android.view.View

/** Robot mini chibi toàn thân (đầu to, thân nhỏ). Cả 4 bot dùng chung, chỉ khác màu nhấn (accent). */
class AvatarView(ctx: Context, private val accent: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val silver = 0xFFEEF1F6.toInt()
    private val dark = 0xFF12151C.toInt()
    private val steel = 0xFF3A4050.toInt()

    private fun darken(c: Int, k: Float = 0.7f): Int {
        val hsv = FloatArray(3); Color.colorToHSV(c, hsv); hsv[2] *= k
        return Color.HSVToColor(hsv)
    }
    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        p.color = color; c.drawRoundRect(RectF(l, t, r, b), rad, rad, p)
    }

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height) / 100f
        c.save()
        c.translate((width - 100 * s) / 2f, (height - 100 * s) / 2f)
        c.scale(s, s)
        p.style = Paint.Style.FILL

        // vầng sáng nền + bóng dưới chân
        p.color = accent; p.alpha = 40; c.drawCircle(50f, 50f, 49f, p)
        p.color = Color.BLACK; p.alpha = 70; c.drawOval(RectF(26f, 94f, 74f, 99f), p); p.alpha = 255

        // ăng-ten
        rr(c, 48.5f, 2f, 51.5f, 10f, 1.5f, 0xFFB0B7C3.toInt())
        p.color = accent; c.drawCircle(50f, 3.5f, 3.6f, p)
        p.color = Color.WHITE; p.alpha = 170; c.drawCircle(48.8f, 2.4f, 1.1f, p); p.alpha = 255

        // chân + bàn chân
        rr(c, 36f, 79f, 46f, 92f, 4f, steel)
        rr(c, 54f, 79f, 64f, 92f, 4f, steel)
        rr(c, 31f, 89f, 47.5f, 96f, 4f, accent)
        rr(c, 52.5f, 89f, 69f, 96f, 4f, accent)

        // tay + bàn tay
        rr(c, 18.5f, 56f, 29f, 76f, 5.2f, accent)
        rr(c, 71f, 56f, 81.5f, 76f, 5.2f, accent)
        p.color = silver
        c.drawCircle(23.7f, 78.5f, 4.8f, p); c.drawCircle(76.3f, 78.5f, 4.8f, p)

        // cổ + thân
        rr(c, 45f, 51f, 55f, 56f, 2f, steel)
        rr(c, 29f, 54f, 71f, 82f, 11f, silver)
        // bảng điều khiển trước ngực
        rr(c, 37f, 60f, 63f, 75f, 6f, darken(accent, 0.55f))
        p.color = accent; c.drawCircle(50f, 67.5f, 4.6f, p)
        p.color = Color.WHITE; p.alpha = 220; c.drawCircle(50f, 67.5f, 1.8f, p); p.alpha = 255
        // đai thân
        rr(c, 29f, 76.5f, 71f, 79f, 1.2f, accent)

        // tai nghe
        rr(c, 10.5f, 22f, 18.5f, 41f, 5f, accent)
        rr(c, 81.5f, 22f, 89.5f, 41f, 5f, accent)

        // đầu
        rr(c, 17f, 8f, 83f, 53f, 19f, silver)
        rr(c, 25f, 11f, 75f, 15.5f, 2.5f, Color.WHITE)
        // mặt kính
        rr(c, 23f, 17f, 77f, 47f, 13f, dark)
        // mắt
        rr(c, 33.5f, 22f, 42.5f, 35f, 4.5f, accent)
        rr(c, 57.5f, 22f, 66.5f, 35f, 4.5f, accent)
        p.color = Color.WHITE; p.alpha = 190
        c.drawCircle(36.5f, 25.5f, 1.4f, p); c.drawCircle(60.5f, 25.5f, 1.4f, p); p.alpha = 255
        // nụ cười
        p.color = accent; p.style = Paint.Style.STROKE; p.strokeWidth = 2.6f; p.strokeCap = Paint.Cap.ROUND
        c.drawArc(RectF(42f, 31f, 58f, 43f), 25f, 130f, false, p)
        p.style = Paint.Style.FILL

        c.restore()
    }
}
