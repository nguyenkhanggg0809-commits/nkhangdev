package com.nkhangdev.team
import android.content.*
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.text.util.Linkify
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class BotActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bot = Bot.valueOf(intent.getStringExtra("bot") ?: "CODE")
        val hint = when (bot) {
            Bot.CODE -> "Mô tả code cần viết hoặc dán code cần sửa..."
            Bot.IMAGE -> "Mô tả ảnh bạn muốn..."
            Bot.VIDEO -> "Mô tả video bạn muốn..."
            Bot.SEARCH -> "Hỏi để tra cứu, hoặc gõ 'làm: mở YouTube tìm bài ...' để tự thao tác"
        }
        setTitle("${bot.label} – ${bot.role}")
        supportActionBar?.setBackgroundDrawable(ColorDrawable(bot.color))

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(AvatarView(this, bot.color), LinearLayout.LayoutParams(dp(110), dp(110)))
        header.addView(TextView(this).apply {
            text = "${bot.label}\n${bot.role}"; textSize = 18f
            setTextColor(bot.color); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(12), 0, 0, 0)
        })
        val input = EditText(this).apply { this.hint = hint; minLines = 3 }
        val send = Button(this).apply {
            text = "Gửi"; setTextColor(0xFFFFFFFF.toInt())
            backgroundTintList = ColorStateList.valueOf(bot.color)
        }
        val copy = Button(this).apply { text = "Sao chép kết quả" }
        val cfg = Button(this).apply { text = "Cài đặt API key" }
        val tv = TextView(this).apply { setTextIsSelectable(true); textSize = 15f }
        val img = ImageView(this).apply { adjustViewBounds = true }

        send.setOnClickListener {
            tv.text = "Đang xử lý..."; img.setImageDrawable(null)
            BotRouter.run(this, bot, input.text.toString(),
                { t -> ui.post { tv.text = t; Linkify.addLinks(tv, Linkify.WEB_URLS) } },
                { bmp -> ui.post { img.setImageBitmap(bmp) } })
        }
        copy.setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("nk", tv.text))
            Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
        }
        cfg.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        listOf(header, input, send, copy, cfg, img, tv).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
