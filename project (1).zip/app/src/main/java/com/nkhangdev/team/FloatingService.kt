package com.nkhangdev.team
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    private fun card(bot: Bot): View {
        val svc = this
        return LinearLayout(svc).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(12), dp(4))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat(); setColor(0xFF1B1F2A.toInt()); setStroke(dp(2), bot.color)
            }
            addView(AvatarView(svc, bot.color), LinearLayout.LayoutParams(dp(66), dp(66)))
            addView(TextView(svc).apply {
                text = "${bot.label}\n${bot.role}"
                setTextColor(0xFFFFFFFF.toInt()); textSize = 12f; setPadding(dp(8), 0, 0, 0)
            })
            setOnClickListener {
                svc.startActivity(Intent(svc, BotActivity::class.java)
                    .putExtra("bot", bot.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val ch = "nkhangdev"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "NKHANGDEV", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, ch)
            .setContentTitle("NKHANGDEV Team đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }

        val svc = this
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat(); setColor(0xE6101420.toInt())
            }
        }
        val handle = TextView(svc).apply {
            text = "⠿ NKHANGDEV TEAM (kéo)"; setTextColor(0xFFFFFFFF.toInt()); textSize = 12f
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        var dx = 0f; var dy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }
        p.addView(handle)
        Bot.values().forEach { bot ->
            p.addView(card(bot), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) })
        }
        p.addView(Button(svc).apply {
            text = "STOP"; setTextColor(0xFFFFFFFF.toInt()); setBackgroundColor(0xFFD32F2F.toInt())
            setOnClickListener { Agent.stop() }
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(8) })
        panel = p
        wm.addView(p, lp)
    }

    override fun onDestroy() { panel?.let { wm.removeView(it) }; super.onDestroy() }
}
