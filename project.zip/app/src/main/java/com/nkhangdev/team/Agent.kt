package com.nkhangdev.team
import android.content.Context
import android.content.Intent
import org.json.JSONObject

object Agent {
    @Volatile var running = false

    private const val SYS = """Bạn là agent điều khiển điện thoại Android. Mỗi lượt, dựa vào nhiệm vụ và danh sách phần tử màn hình, trả về DUY NHẤT một JSON, không giải thích:
{"action":"open_app|click_text|tap|type|swipe_up|swipe_down|back|home|wait|done","text":"...","x":0,"y":0,"say":"nói ngắn gọn bạn đang làm gì"}
- open_app: text = tên ứng dụng. click_text: text = chữ trên nút. tap: x,y lấy từ center. type: gõ vào ô đang chọn.
- done: khi hoàn thành hoặc không thể làm tiếp, say = kết quả.
Quy tắc an toàn: KHÔNG chuyển tiền, thanh toán, xóa dữ liệu, nhập mật khẩu hay gửi tin nhắn nếu nhiệm vụ không yêu cầu rõ ràng."""

    fun stop() { running = false }

    fun start(ctx: Context, goal: String, say: (String) -> Unit) {
        if (running) { say("Agent đang chạy. Bấm STOP trước."); return }
        val svc = BotAccessibilityService.instance
        if (svc == null) { say("Chưa bật dịch vụ trợ năng NKHANGDEV (Cài đặt → Trợ năng)."); return }
        running = true
        Thread {
            try {
                val hist = StringBuilder()
                for (step in 1..20) {
                    if (!running) { say("Đã dừng."); return@Thread }
                    val screen = svc.dumpScreen()
                    val reply = Api.claude(ctx, SYS,
                        "Nhiệm vụ: $goal\nCác bước đã làm:\n$hist\nMàn hình hiện tại:\n$screen")
                    val j = JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
                    val act = j.optString("action"); val t = j.optString("text")
                    say("Bước $step: ${j.optString("say")}")
                    hist.append("$step. $act $t ${j.optString("x")},${j.optString("y")}\n")
                    when (act) {
                        "open_app" -> openApp(ctx, t)
                        "click_text" -> if (!svc.clickByText(t)) hist.append("  (không thấy '$t')\n")
                        "tap" -> svc.tap(j.optDouble("x").toFloat(), j.optDouble("y").toFloat())
                        "type" -> svc.typeText(t)
                        "swipe_up" -> svc.swipe(540f, 1600f, 540f, 600f)
                        "swipe_down" -> svc.swipe(540f, 600f, 540f, 1600f)
                        "back" -> svc.back()
                        "home" -> svc.home()
                        "done" -> { say("Xong: ${j.optString("say")}"); return@Thread }
                    }
                    Thread.sleep(if (act == "wait") 3000 else 1500)
                }
                say("Đã chạy tối đa 20 bước. Dừng lại.")
            } catch (e: Exception) { say("Lỗi agent: ${e.message}") }
            finally { running = false }
        }.start()
    }

    private fun openApp(ctx: Context, name: String) {
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ri = pm.queryIntentActivities(q, 0).firstOrNull { it.loadLabel(pm).toString().contains(name, true) } ?: return
        pm.getLaunchIntentForPackage(ri.activityInfo.packageName)
            ?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)?.let { ctx.startActivity(it) }
    }
}
