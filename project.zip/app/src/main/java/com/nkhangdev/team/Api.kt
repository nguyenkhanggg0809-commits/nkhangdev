package com.nkhangdev.team
import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.util.concurrent.TimeUnit

object Api {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(180, TimeUnit.SECONDS).build()
    private val JSON_T = "application/json".toMediaType()

    private fun exec(rb: Request.Builder, h: Map<String, String>): JSONObject {
        h.forEach { (k, v) -> rb.addHeader(k, v) }
        client.newCall(rb.build()).execute().use { r ->
            val t = r.body?.string() ?: "{}"
            if (!r.isSuccessful) throw Exception("HTTP ${r.code}: ${t.take(300)}")
            return JSONObject(t)
        }
    }
    fun post(url: String, h: Map<String, String>, body: JSONObject) =
        exec(Request.Builder().url(url).post(body.toString().toRequestBody(JSON_T)), h)
    fun get(url: String, h: Map<String, String>) = exec(Request.Builder().url(url).get(), h)

    fun claude(ctx: Context, system: String, user: String, search: Boolean = false): String {
        val key = Prefs.get(ctx, "claude")
        if (key.isBlank()) throw Exception("Chưa nhập Claude API key (Cài đặt)")
        val body = JSONObject()
            .put("model", "claude-sonnet-4-6").put("max_tokens", 4000).put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", user)))
        if (search) body.put("tools", JSONArray().put(JSONObject()
            .put("type", "web_search_20250305").put("name", "web_search").put("max_uses", 5)))
        val r = post("https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
        val c = r.getJSONArray("content"); val sb = StringBuilder()
        for (i in 0 until c.length()) {
            val b = c.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.getString("text"))
        }
        return sb.toString()
    }
}
