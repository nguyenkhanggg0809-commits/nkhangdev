package com.nkhangdev.team
import android.content.*
import android.os.*
import android.text.util.Linkify
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class BotActivity : AppCompatActivity() {
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val bot = Bot.valueOf(intent.getStringExtra("bot") ?: "CODE")
        val (title, hint) = when (bot) {
            Bot.CODE -> "NKHANGDEV_Bot 001 – Code" to "Mô tả code cần viết hoặc dán code cần sửa..."
            Bot.IMAGE -> "NKHANGDEV_Bot 002 – Tạo ảnh" to "Mô tả ảnh bạn muốn..."
            Bot.VIDEO -> "NKHANGDEV_Bot 003 – Tạo video" to "Mô tả video bạn muốn..."
            Bot.SEARCH -> "NKHANGDEV_Bot 004 – Tìm kiếm / Tự động" to
                "Hỏi để tra cứu, hoặc gõ 'làm: mở YouTube tìm bài ...' để tự thao tác"
        }
        setTitle(title)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        val input = EditText(this).apply { this.hint = hint; minLines = 3 }
        val send = Button(this).apply { text = "Gửi" }
        val copy = Button(this).apply { text = "Sao chép kết quả" }
        val cfg = Button(this).apply { text = "Cài đặt API key" }
        val tv = TextView(this).apply { setTextIsSelectable(true); textSize = 15f }
        val img = ImageView(this).apply { adjustViewBounds = true }

        send.setOnClickListener {
            tv.text = "Đang xử lý..."; img.setImageDrawable(null)
            BotRouter.run(this, bot, input.text.toString(),
                { t -> ui.post { tv.text = t; Linkify.addLinks(tv, Linkify.WEB_URLS) } },
                { bmp -> ui.post { img.setImageBitmap(bmp) } })
        }
        copy.setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("nk", tv.text))
            Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
        }
        cfg.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        listOf(input, send, copy, cfg, img, tv).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
