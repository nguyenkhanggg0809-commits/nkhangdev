package com.nkhangdev.team
import android.content.Context
import android.graphics.Bitmap

enum class Bot { CODE, IMAGE, VIDEO, SEARCH }

object BotRouter {
    private const val CODE_SYS = "Bạn là NKHANGDEV_Bot 001, kỹ sư lập trình giỏi. Viết, sửa, giải thích code chính xác, đầy đủ, chạy được. Trả lời tiếng Việt, code đặt trong khối code, nói rõ file nào cần sửa."
    private const val SEARCH_SYS = "Bạn là NKHANGDEV_Bot 004, trợ lý tra cứu. Tìm thông tin mới nhất trên web, tóm tắt rõ ràng bằng tiếng Việt và nêu nguồn."

    fun run(ctx: Context, bot: Bot, prompt: String, onText: (String) -> Unit, onImage: (Bitmap) -> Unit) {
        val app = ctx.applicationContext
        if (prompt.isBlank()) { onText("Hãy nhập yêu cầu."); return }
        Thread {
            try {
                when (bot) {
                    Bot.CODE -> onText(Api.claude(app, CODE_SYS, prompt))
                    Bot.IMAGE -> {
                        val bmp = Media.image(app, prompt); Media.save(app, bmp); onImage(bmp)
                        onText("Đã tạo và lưu ảnh vào thư viện (Pictures/NKHANGDEV).")
                    }
                    Bot.VIDEO -> {
                        onText("Đang tạo video, có thể mất 1–3 phút...")
                        onText("Video xong:\n" + Media.video(app, prompt))
                    }
                    Bot.SEARCH ->
                        if (prompt.startsWith("làm:", true) || prompt.startsWith("lam:", true)) {
                            BotAccessibilityService.instance?.home()
                            Agent.start(app, prompt.substringAfter(":").trim(), onText)
                        } else onText(Api.claude(app, SEARCH_SYS, prompt, true))
                }
            } catch (e: Exception) { onText("Lỗi: ${e.message}") }
        }.start()
    }
}
