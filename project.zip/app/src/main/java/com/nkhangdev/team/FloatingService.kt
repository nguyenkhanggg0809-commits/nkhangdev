package com.nkhangdev.team
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "nkhangdev"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "NKHANGDEV", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, ch)
            .setContentTitle("NKHANGDEV Team đang chạy")
            .setSmallIcon(android.R.drawable.ic_menu_manage).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }

        val svc = this
        val p = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC111111.toInt())
        }
        val handle = TextView(svc).apply {
            text = "☰ NKHANGDEV (kéo)"; setTextColor(0xFFFFFFFF.toInt()); setPadding(16, 12, 16, 12)
        }
        var dx = 0f; var dy = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = lp.x - e.rawX; dy = lp.y - e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = (e.rawX + dx).toInt(); lp.y = (e.rawY + dy).toInt()
                    wm.updateViewLayout(p, lp)
                }
            }
            true
        }
        p.addView(handle)
        listOf("001 Code" to Bot.CODE, "002 Ảnh" to Bot.IMAGE,
               "003 Video" to Bot.VIDEO, "004 Tìm kiếm" to Bot.SEARCH).forEach { (label, bot) ->
            p.addView(Button(svc).apply {
                text = label
                setOnClickListener {
                    svc.startActivity(Intent(svc, BotActivity::class.java)
                        .putExtra("bot", bot.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            })
        }
        p.addView(Button(svc).apply { text = "STOP"; setOnClickListener { Agent.stop() } })
        panel = p
        wm.addView(p, lp)
    }

    override fun onDestroy() { panel?.let { wm.removeView(it) }; super.onDestroy() }
}
