package com.nkhangdev.team
import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.provider.MediaStore
import android.util.Base64
import okhttp3.Request
import org.json.*
import java.net.URLEncoder

object Media {
    fun image(ctx: Context, prompt: String): Bitmap {
        val key = Prefs.get(ctx, "openai")
        if (key.isNotBlank()) {
            val r = Api.post("https://api.openai.com/v1/images/generations",
                mapOf("Authorization" to "Bearer $key"),
                JSONObject().put("model", "gpt-image-1").put("prompt", prompt).put("size", "1024x1024"))
            val b = Base64.decode(r.getJSONArray("data").getJSONObject(0).getString("b64_json"), Base64.DEFAULT)
            return BitmapFactory.decodeByteArray(b, 0, b.size)
        }
        val url = "https://image.pollinations.ai/prompt/" + URLEncoder.encode(prompt, "UTF-8") +
            "?width=1024&height=1024&nologo=true"
        Api.client.newCall(Request.Builder().url(url).build()).execute().use { r ->
            val b = r.body!!.bytes()
            return BitmapFactory.decodeByteArray(b, 0, b.size) ?: throw Exception("Không tạo được ảnh")
        }
    }

    fun save(ctx: Context, bmp: Bitmap) {
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "nk_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NKHANGDEV")
        }
        val u = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(u)!!.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    fun video(ctx: Context, prompt: String): String {
        val key = Prefs.get(ctx, "replicate")
        if (key.isBlank()) throw Exception("Chưa nhập Replicate API key (Cài đặt)")
        val h = mapOf("Authorization" to "Bearer $key")
        var p = Api.post("https://api.replicate.com/v1/models/minimax/video-01/predictions", h,
            JSONObject().put("input", JSONObject().put("prompt", prompt)))
        val getUrl = p.getJSONObject("urls").getString("get")
        repeat(90) {
            Thread.sleep(4000)
            p = Api.get(getUrl, h)
            when (p.getString("status")) {
                "succeeded" -> { val o = p.get("output"); return if (o is JSONArray) o.getString(0) else o.toString() }
                "failed", "canceled" -> throw Exception(p.optString("error", "Tạo video thất bại"))
            }
        }
        throw Exception("Quá thời gian chờ video")
    }
}
