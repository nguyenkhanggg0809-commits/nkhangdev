package com.nkhangdev.team
import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("nk", 0)
    fun get(c: Context, k: String) = sp(c).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
}
