package com.nkhangdev.team
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setTitle("Cài đặt API key")
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32) }
        val fields = listOf("claude" to "Claude API key (Bot 001, 004)",
            "replicate" to "Replicate API key (Bot 003)",
            "openai" to "OpenAI API key (Bot 002, tùy chọn)")
        val act = this
        val edits = fields.map { (k, label) ->
            root.addView(TextView(act).apply { text = label })
            EditText(act).apply { setText(Prefs.get(act, k)); setSingleLine() }.also { root.addView(it) }
        }
        root.addView(Button(act).apply {
            text = "Lưu"
            setOnClickListener {
                fields.forEachIndexed { i, f -> Prefs.set(act, f.first, edits[i].text.toString().trim()) }
                Toast.makeText(act, "Đã lưu", Toast.LENGTH_SHORT).show(); act.finish()
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
